"use strict";

var gulp = require("gulp");
var gutil = require("gulp-util");
var uglify = require("gulp-uglify"),
  concat = require("gulp-concat");
var csso = require("gulp-csso");
var inject = require("gulp-inject");

gulp.task("index", async function() {
  var target = gulp.src("./replacementPortal/index.html");
  // It's not necessary to read the files (will speed up things), we're only after their paths:
  var sources = gulp.src(
    [
      "./replacementPortal/src/scripts/*.js",
      "./replacementPortal/src/styles/*.css"
    ],
    { read: false }
  );

  return target.pipe(inject(sources)).pipe(gulp.dest("./replacementPortal"));
});

// for merging the html from different file method start ******************
var fs = require("fs");
var dom = require("jsdom");
var input = "replacementPortal/src/components/header/header.html";
var input1 = "replacementPortal/src/components/footer/footer.html";
var output = "replacementPortal/index.html";
var htmlTempFile = "replacementPortal/src/html";

var HtmlInputArray = [
  {
    path: "replacementPortal/src/components/header/header.html",
    extractFrom: "#extraction-location-header",
    subLayout: [
      {
        path: "replacementPortal/src/components/navigation/navigation.html",
        extractFrom: "#extraction-location-navigation",
        insertAt: "#extraction-location-header1"
      },
      {
        path: "replacementPortal/src/components/navigation/navigation.html",
        extractFrom: "#extraction-location-navigation",
        insertAt: "#extraction-location-header2"
      }
    ],
    dest: "replacementPortal/src/html/header.html"
  },
  {
    path: "replacementPortal/src/components/footer/footer.html",
    extractFrom: "#extraction-location-footer"
  }
];

gulp.task("copy-html", async function() {
  var HTMLContentList = [];
  var HTMLSubContentList = [];
  for (var i = 0; i < HtmlInputArray.length; i++) {
    dom.JSDOM.fromFile(HtmlInputArray[i].path).then(
      function(config, htmlContentList, d) {
        htmlContentList.push(
          d.window.document.querySelector(config.extractFrom).innerHTML
        );
      }.bind(undefined, HtmlInputArray[i], HTMLContentList)
    );
    if (HtmlInputArray[i].subLayout) {
      for (var j = 0; j < HtmlInputArray[i].subLayout.length; j++) {
        gulp.src(HtmlInputArray[i].path).pipe(gulp.dest(htmlTempFile));
        dom.JSDOM.fromFile(HtmlInputArray[i].subLayout[j].path).then(
          function(config, hTMLSubContentList, d) {
            hTMLSubContentList.push(
              d.window.document.querySelector(config.extractFrom).innerHTML
            );
          }.bind(undefined, HtmlInputArray[i].subLayout[j], HTMLSubContentList)
        );
      }
      dom.JSDOM.fromFile(HtmlInputArray[i].path).then(
        function(hTMLSubContentList, d) {
          d.window.document.querySelector(
            "body"
          ).innerHTML += hTMLSubContentList.join("\n");
          saveOutput(d.serialize(d.window.document.documentElement.innerHTML));
        }.bind(undefined, HTMLSubContentList)
      );
    }
  }
  dom.JSDOM.fromFile(output).then(
    function(htmlContentList, d) {
      d.window.document.querySelector("body").innerHTML += htmlContentList.join(
        "\n"
      );
      saveOutput(d.serialize(d.window.document.documentElement.innerHTML));
    }.bind(undefined, HTMLContentList)
  );
});

function saveOutput(data) {
  fs.writeFile(output, data, function(error) {
    if (error) {
      throw error;
    }
    console.log("Copied portion to output successfully.");
  });
}

// for merging the html from different file method end ******************

var copySourcesJs = [
  "replacementPortal/src/components/footer/footer.js",
  "replacementPortal/src/components/header/header.js"
];
var copySourcesCss = [
  "replacementPortal/src/components/header/header.css",
  "replacementPortal/src/components/footer/footer.css"
];

var copyDestJs = "replacementPortal/src/scripts";
var copyDestCss = "replacementPortal/src/styles";

// create copy of all css and js file
gulp.task("copy", async function() {
  gutil.log("Ready to copy the js and css file" + " " + copySourcesJs);
  gulp.src(copySourcesJs).pipe(gulp.dest(copyDestJs));
  gulp.src(copySourcesCss).pipe(gulp.dest(copyDestCss));
  gutil.log("Copied");
});

// concating all js file code into one file
gulp.task("js", async function() {
  gutil.log("Minifying Javascript");
  gulp
    .src(copySourcesJs)
    .pipe(
      uglify({
        output: {
          comments: true
        }
      })
    )
    .pipe(concat("script.js"))
    .pipe(gulp.dest(copyDestJs));
  gutil.log("Created script.js in " + " " + copyDestJs);
});

// concating all css file code into one file
gulp.task("styles", async function() {
  gutil.log("Minifying css");
  gulp
    .src(copySourcesCss)
    .pipe(
      csso({
        output: {
          comments: true
        }
      })
    )
    .pipe(concat("style.css"))
    .pipe(gulp.dest(copyDestCss));
  gutil.log("Created style.css in " + " " + copyDestCss);
});

gulp.task("html", function() {
  return gulp
    .src(copySourcesHtml)
    .pipe(concat("index.html"))
    .pipe(gulp.dest(copyDestHtml));
});

gulp.task("default", gulp.series("copy", "js", "styles"));
